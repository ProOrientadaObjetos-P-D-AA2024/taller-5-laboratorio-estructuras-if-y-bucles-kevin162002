package problema2;
public class empleado {
    
    private String  nombre;
    private double salario;
    private int edad;
    private double calcular,porcentaje;

    public empleado(String  nombre, double salario, int edad) {
        this.nombre = nombre;
        this.salario = salario;
        this.edad = edad;
    }

    public empleado() {

        
    }

   

    public double getPorcentaje() {
        return porcentaje;
    }

    public void setPorcentaje() {

        if (calcular > salario){
                    
            salario = salario*(porcentaje/100) + salario;
            porcentaje = salario;
       }    
    }
    
    public double getCalcular() {
        return calcular;
    }

    public void setCalcular() {
        int n = 0;
        double p = 0;

                p = (salario+ n);
                calcular = (p/2);
    }
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    public String Mostrarinformacion() {
        

    return "El empleado "+nombre+" con la edad de "+edad+" tiene un salario de "+salario;


  }
    

    
}
