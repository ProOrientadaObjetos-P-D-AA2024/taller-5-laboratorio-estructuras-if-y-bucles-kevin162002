package problema2;

import java.util.Scanner;

public class Problema2 {
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner (System.in);
        boolean op;
        op = true;
        int p,edad,n;
        String  nombre;
        double salario,calcular;
        double por;
        
        while (op){
            
            System.out.println("------------------------------");
            System.out.println("Sistema de manejo de empleados");
            System.out.println("------------------------------");
            System.out.print("Ingrese una opcion: ");
            System.out.println("\nIngrese 1 :Si desea agregar un empleado ");
        p = entrada.nextInt();
            
        switch (p){
            
            case 1:
                entrada.nextLine();
                System.out.println("Cuanto empleados va a ingresar: ");
                n = entrada.nextInt();

                for ( int i = 0; i < n ; i++ ){
                    entrada.nextLine();
                    System.out.print("\nIngrese el nombre del empleado: ");
                    nombre = entrada.nextLine();
                    System.out.print("Ingrese la edad del empleado: ");
                    edad = entrada.nextInt();
                    System.out.print("Ingrese el salario: ");
                    salario =entrada.nextDouble();
                    
                    empleado em = new empleado(nombre,salario,edad);
                    System.out.println(em.Mostrarinformacion());
                    
                System.out.println("Ingrese el porcentaje para el aumento salarial: ");
                por = entrada.nextDouble();
                
                calcular = (+em.getSalario()+(por/100)) + em.getSalario() ;
                    
                System.out.println("El aumento en el salaio para "+em.getNombre()+" es de "+calcular);
                }
               
               
                break;
            
             default:
                System.out.println("Ingrese un valor entre en 1 y 3");
                break;
            
        }
            
            
            
        }
        
      
        
    }
}
